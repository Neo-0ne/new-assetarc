<section class="container text-center py-10">
    <h2 class="text-2xl font-semibold mb-2">Nothing Found</h2>
    <p>It looks like we couldn’t find anything. Try searching?</p>
    <?php get_search_form(); ?>
</section>
